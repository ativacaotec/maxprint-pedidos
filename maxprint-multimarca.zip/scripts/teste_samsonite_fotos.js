'use strict';

/**
 * Teste do extrator dos catálogos Samsonite / American Tourister / BTS.
 *
 * Roda o importador nos dois PDFs do cliente e imprime os números que
 * interessam: quantas páginas, quantos itens, quantos itens ficaram com foto,
 * quantas cores foram lidas e quantas dessas cores acabaram casadas com uma
 * foto. No fim lista os avisos agrupados, que é onde aparecem os itens
 * problemáticos.
 *
 * Uso:
 *   node scripts/teste_samsonite_fotos.js [caminho-de-um-pdf ...]
 *
 * Sem argumento, usa os dois catálogos enviados pelo cliente.
 */

const fs = require('fs');
const path = require('path');
const { importarCatalogoSamsonite } = require('../lib/importCatalogoSamsonite');

const PADRAO = [
  '/root/.claude/uploads/6dfea4e2-4c19-536d-8788-2e828ccb4a97/14593d90-Catalogo_Samsonite_e_American_Tourister_26_rep_1.pdf',
  '/root/.claude/uploads/6dfea4e2-4c19-536d-8788-2e828ccb4a97/1124b0fb-Catalogo_BTS_27_PT_BR__23_1_.pdf',
];

const SAIDA = process.env.SAIDA_TESTE || '/tmp/samsonite-fotos';

function resumo(rotulo, r) {
  const itens = r.itens;
  const cores = itens.reduce((a, i) => a + i.cores.length, 0);
  const coresComFoto = itens.reduce((a, i) => a + i.cores.filter((c) => c.arquivoImagem).length, 0);
  const fotos = itens.reduce((a, i) => a + i.imagens.length, 0);

  console.log(`\n===== ${rotulo}`);
  console.log(`  páginas ............... ${r.paginas}`);
  console.log(`  itens ................. ${itens.length}`);
  console.log(`  itens com foto ........ ${itens.filter((i) => i.imagens.length).length}`);
  console.log(`  fotos recortadas ...... ${fotos}`);
  console.log(`  itens com preço ....... ${itens.filter((i) => i.wholesale).length}`);
  console.log(`  itens com NCM ......... ${itens.filter((i) => i.especificacoes.ncm).length}`);
  console.log(`  cores lidas ........... ${cores}`);
  console.log(`  cores com foto casada . ${coresComFoto}`);
  console.log(`  avisos ................ ${r.avisos.length}`);

  const semFoto = itens.filter((i) => !i.imagens.length);
  if (semFoto.length) {
    console.log('\n  -- itens sem foto:');
    for (const i of semFoto.slice(0, 25)) {
      console.log(`     p${i.pagina} ${i.modelo} | ${i.tipo} | ${i.materialDescription || i.codigo}`);
    }
    if (semFoto.length > 25) console.log(`     ... e mais ${semFoto.length - 25}`);
  }

  console.log('\n  -- amostra de itens:');
  const passo = Math.max(1, Math.floor(itens.length / 8));
  for (let k = 0; k < itens.length; k += passo) {
    const i = itens[k];
    const cor = i.cores.map((c) => `${c.hex}${c.sigla ? '(' + c.sigla + ')' : ''}->${c.arquivoImagem || '-'}`).join(' ');
    console.log(
      `     p${i.pagina} [${i.modelo}] ${i.tipo} | ${i.materialGroup} | ${i.materialDescription} | ` +
      `R$ ${i.wholesale ?? '-'} | ${i.especificacoes.medidas || '-'} | fotos=${i.imagens.length} | ${cor}`
    );
  }

  if (r.avisos.length) {
    console.log('\n  -- avisos:');
    for (const a of r.avisos) console.log(`     ${a}`);
  }
  return { itens: itens.length, cores, coresComFoto };
}

(async () => {
  const arquivos = process.argv.slice(2).length ? process.argv.slice(2) : PADRAO;
  fs.rmSync(SAIDA, { recursive: true, force: true });

  const totais = { itens: 0, cores: 0, coresComFoto: 0 };
  const relatorios = [];

  for (const arq of arquivos) {
    if (!fs.existsSync(arq)) {
      console.log(`\n!! não achei ${arq}`);
      continue;
    }
    const nome = path.basename(arq);
    const inicio = Date.now();
    const r = await importarCatalogoSamsonite(arq, {
      pastaImagens: path.join(SAIDA, nome.slice(0, 12)),
      prefixo: nome.slice(0, 8).replace(/[^A-Za-z0-9]/g, ''),
      dpi: Number(process.env.DPI || 150),
      aoProgredir: (n, total) => {
        if (n % 5 === 0 || n === total) process.stdout.write(`\r  ${nome}: página ${n}/${total}   `);
      },
    });
    const parcial = resumo(`${nome}  (${((Date.now() - inicio) / 1000).toFixed(0)}s)`, r);
    totais.itens += parcial.itens;
    totais.cores += parcial.cores;
    totais.coresComFoto += parcial.coresComFoto;
    relatorios.push({ arquivo: nome, itens: r.itens, avisos: r.avisos });
  }

  console.log('\n===== TOTAL DOS DOIS CATÁLOGOS');
  console.log(`  itens ................. ${totais.itens}`);
  console.log(`  cores ................. ${totais.cores}`);
  console.log(`  cores com foto casada . ${totais.coresComFoto}`);
  console.log(`\n  recortes em ${SAIDA}`);

  // O JSON serve para conferir item a item sem ter que rodar tudo de novo.
  fs.writeFileSync(path.join(SAIDA, 'resultado.json'), JSON.stringify(relatorios, null, 1));
})();
