'use strict';

/**
 * Teste do cruzamento base + fotos da Samsonite, contra os arquivos reais.
 *
 * Uso:
 *   node scripts/teste_samsonite_cruzamento.js
 *
 * Espera encontrar:
 *   /home/claude/samsonite.html                 (base HTML)
 *   os dois PDFs em /root/.claude/uploads/.../
 *
 * Se as fotos já foram extraídas antes (scripts/teste_samsonite_fotos.js),
 * reaproveita o resultado salvo para não gastar minutos rasterizando de novo.
 */

const fs = require('fs');
const path = require('path');

const { importarSamsonite } = require('../lib/importSamsonite');
const { importarCatalogoSamsonite } = require('../lib/importCatalogoSamsonite');
const { cruzarComFotos } = require('../lib/cruzamentoSamsonite');

const CACHE = '/tmp/samsonite-fotos/resultado.json';
const PDF_SAMSONITE = '/root/.claude/uploads/6dfea4e2-4c19-536d-8788-2e828ccb4a97/14593d90-Catalogo_Samsonite_e_American_Tourister_26_rep_1.pdf';
const PDF_BTS = '/root/.claude/uploads/6dfea4e2-4c19-536d-8788-2e828ccb4a97/1124b0fb-Catalogo_BTS_27_PT_BR__23_1_.pdf';

(async () => {
  const { produtos, relatorio: relBase } = await importarSamsonite('/home/claude/samsonite.html', {
    pastaImagens: '/tmp/basetest-cruz',
    prefixo: 'x',
  });
  console.log('== Base ==');
  console.log(` ${relBase.totalValido} itens, ${relBase.gruposDeCor} grupos de cor`);

  let catalogos;
  if (fs.existsSync(CACHE)) {
    console.log('\n(usando fotos já extraídas em', CACHE, ')');
    catalogos = JSON.parse(fs.readFileSync(CACHE, 'utf8'));
  } else {
    console.log('\nExtraindo fotos dos dois PDFs (leva alguns minutos)...');
    const a = await importarCatalogoSamsonite(PDF_SAMSONITE, { pastaImagens: '/tmp/samsonite-fotos-2', prefixo: '14593d90' });
    const b = await importarCatalogoSamsonite(PDF_BTS, { pastaImagens: '/tmp/samsonite-fotos-2', prefixo: '1124b0fb' });
    catalogos = [a, b];
    fs.mkdirSync('/tmp/samsonite-fotos-2', { recursive: true });
    fs.writeFileSync('/tmp/samsonite-fotos-2/resultado.json', JSON.stringify(catalogos));
  }

  const { relatorio, avisos } = cruzarComFotos(produtos, catalogos);

  console.log('\n== Cruzamento ==');
  console.log(` total na base ......... ${relatorio.totalBase}`);
  console.log(` com foto .............. ${relatorio.totalComFoto}  (${(100 * relatorio.totalComFoto / relatorio.totalBase).toFixed(0)}%)`);
  console.log(` sem foto .............. ${relatorio.totalSemFoto}`);
  console.log(` casados por código (Xtrem/BTS) ... ${relatorio.casadosPorCodigo}`);
  console.log(` linhas de produto casadas por texto (Samsonite/AT) ... ${relatorio.itensDeTextoCasados}`);
  console.log(` cores casadas por texto+cor ...... ${relatorio.coresCasadasPorTexto}`);

  console.log(`\n== Avisos (${avisos.length}, primeiros 15) ==`);
  avisos.slice(0, 15).forEach((a) => console.log('  ·', a));

  // por sub-marca, para ver se alguma ficou muito para trás
  const porSubMarca = {};
  for (const p of produtos) {
    const k = p.subMarca || '(sem)';
    porSubMarca[k] = porSubMarca[k] || { total: 0, comFoto: 0 };
    porSubMarca[k].total++;
    if (p.imagem) porSubMarca[k].comFoto++;
  }
  console.log('\n== Por sub-marca ==');
  for (const [k, v] of Object.entries(porSubMarca)) {
    console.log(`  ${k}: ${v.comFoto}/${v.total} (${(100 * v.comFoto / v.total).toFixed(0)}%)`);
  }

  // amostra para conferência visual: 10 produtos com foto, de sub-marcas
  // diferentes, priorizando os que têm cor no nome (mais fácil de checar).
  const amostra = [];
  for (const sub of ['Xtrem', 'Samsonite', 'American Tourister']) {
    const candidatos = produtos.filter((p) => p.subMarca === sub && p.imagem);
    amostra.push(...candidatos.slice(0, 4));
  }
  console.log('\n== Amostra para conferência visual ==');
  console.log(JSON.stringify(
    amostra.map((p) => ({
      subMarca: p.subMarca, grupo: p.grupo, tipo: p.tipoProduto, cor: p.cor,
      imagem: p.imagem, origem: p.fotoOrigem,
    })),
    null, 1
  ));

  fs.writeFileSync('/tmp/cruzamento_samsonite.json', JSON.stringify({ produtos, avisos }, null, 1));
  console.log('\nResultado completo salvo em /tmp/cruzamento_samsonite.json');
})().catch((e) => { console.error(e); process.exit(1); });
