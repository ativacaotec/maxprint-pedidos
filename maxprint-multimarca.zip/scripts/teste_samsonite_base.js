'use strict';

/**
 * Teste do importador da base Samsonite, contra o arquivo real.
 *
 * Uso:
 *   node scripts/teste_samsonite_base.js [/caminho/do/samsonite.html]
 *
 * Sem argumento, procura em /home/claude/samsonite.html.
 *
 * O que interessa conferir aqui não é "rodou sem erro", e sim as três coisas
 * que quebram o catálogo do cliente se saírem erradas: produto sem preço,
 * grupo de cor torto (irmão que não aponta de volta, ou que mistura marcas
 * diferentes) e código repetido, que faria dois itens virarem um.
 */

const fs = require('fs');
const os = require('os');
const path = require('path');

const { importarSamsonite } = require('../lib/importSamsonite');
const { normalizarCodigo } = require('../lib/codigo');

let falhas = 0;
function conferir(descricao, condicao, detalhe = '') {
  const ok = Boolean(condicao);
  if (!ok) falhas++;
  console.log(`  ${ok ? '✓' : '✗'} ${descricao}${detalhe ? '  ' + detalhe : ''}`);
}

(async () => {
  const arquivo = process.argv[2] || '/home/claude/samsonite.html';
  if (!fs.existsSync(arquivo)) {
    console.error(`Não achei o arquivo da Samsonite em ${arquivo}.`);
    process.exit(1);
  }

  const pastaImagens = fs.mkdtempSync(path.join(os.tmpdir(), 'teste-sams-'));
  const { produtos, relatorio, avisos } = await importarSamsonite(arquivo, {
    pastaImagens,
    prefixo: 'sams',
  });

  console.log('\n== 1. Relatório da importação ==');
  console.log(`  · arquivo: ${relatorio.arquivo}`);
  console.log(`  · ${relatorio.totalLido} itens lidos, ${relatorio.totalValido} válidos`);
  console.log(`  · por sub-marca: ${Object.entries(relatorio.porSubMarca)
    .sort((a, b) => b[1] - a[1])
    .map(([m, n]) => `${m} ${n}`)
    .join(', ')}`);
  console.log(`  · ${relatorio.comSaldo} com saldo, ${relatorio.semSaldo} sem saldo (previsão zero)`);
  console.log(`  · ${relatorio.emPromocao} em promoção`);
  console.log(`  · ${relatorio.gruposDeCor} grupos de cor, cobrindo ${relatorio.itensEmGrupoDeCor} itens`);
  console.log(`  · ${relatorio.comPagina} com página de catálogo, ${relatorio.comImagemPagina} com imagem ` +
    `(${relatorio.paginasComImagem} arquivos gravados)`);
  console.log(`  · ${relatorio.foraPorFaltaDePreco} fora por falta de preço`);
  console.log(`  · ${relatorio.duplicados} SKU(s) duplicado(s) descartado(s)`);
  if (avisos.length) console.log(`  · ${avisos.length} aviso(s); primeiro: ${avisos[0]}`);

  console.log('\n== 2. Total lido ==');
  conferir('o arquivo entregou os 1546 itens conhecidos', relatorio.totalLido === 1546,
    `(leu ${relatorio.totalLido})`);
  conferir('válidos + descartados por preço fecham com o total lido',
    relatorio.totalValido + relatorio.foraPorFaltaDePreco + relatorio.duplicados === relatorio.totalLido,
    `(${relatorio.totalValido} + ${relatorio.foraPorFaltaDePreco} + ${relatorio.duplicados})`);

  console.log('\n== 3. Preço ==');
  const semPreco = produtos.filter((p) => !(p.precoBase > 0));
  conferir('nenhum produto saiu sem preço', semPreco.length === 0,
    semPreco.length ? `(ex.: ${semPreco[0].codigo})` : '');
  const promoErrada = produtos.filter((p) => p.emPromocao && !(p.precoBase <= p.precoCheio));
  conferir('item em promoção nunca custa mais que o preço cheio', promoErrada.length === 0,
    promoErrada.length ? `(ex.: ${promoErrada[0].codigo})` : '');
  conferir('item fora de promoção usa o preço cheio como base',
    produtos.filter((p) => !p.emPromocao).every((p) => Math.abs(p.precoBase - p.precoCheio) < 0.005));

  // O campo `promo` do arquivo é percentual de desconto, não preço. Se alguém
  // um dia trocar isso no importador, o catálogo passa a vender mala de 380
  // reais por 40 — esta conferência é justamente a trava contra esse erro.
  const promocionais = produtos.filter((p) => p.emPromocao);
  const contaErrada = promocionais.filter(
    (p) => Math.abs(p.precoBase - p.precoCheio * (1 - p.descontoPromo / 100)) > 0.02
  );
  conferir('o desconto promocional é percentual e bate com o preço cobrado',
    promocionais.length > 0 && contaErrada.length === 0,
    contaErrada.length
      ? `(ex.: ${contaErrada[0].codigo}: ${contaErrada[0].precoCheio} -${contaErrada[0].descontoPromo}% ≠ ${contaErrada[0].precoBase})`
      : `(${promocionais.length} itens, descontos de ${[...new Set(promocionais.map((p) => p.descontoPromo))].sort((a, b) => a - b).join('%, ')}%)`);
  conferir('nenhum preço promocional ficou absurdamente baixo',
    promocionais.every((p) => p.precoBase >= p.precoCheio * 0.45),
    `(menor razão ${Math.min(...promocionais.map((p) => p.precoBase / p.precoCheio)).toFixed(2)})`);

  console.log('\n== 4. Código normalizado ==');
  const porCodigo = new Map();
  const repetidos = [];
  for (const p of produtos) {
    if (porCodigo.has(p.codigo)) repetidos.push(p.codigo);
    else porCodigo.set(p.codigo, p);
  }
  conferir('os códigos normalizados são únicos', repetidos.length === 0,
    repetidos.length ? `(ex.: ${repetidos[0]})` : `(${porCodigo.size} códigos)`);
  conferir('o código é mesmo a normalização do SKU original',
    produtos.every((p) => p.codigo === normalizarCodigo(p.codigoOriginal)));
  conferir('o SKU original foi preservado com os espaços de origem',
    produtos.some((p) => /\s/.test(p.codigoOriginal)),
    `(ex.: "${produtos[0].codigoOriginal}" → ${produtos[0].codigo})`);

  console.log('\n== 5. Grupos de cor ==');
  const comGrupo = produtos.filter((p) => p.grupoCores.length > 0);
  conferir('formou grupo de cor', comGrupo.length > 0, `(${comGrupo.length} itens agrupados)`);

  let assimetria = null;
  for (const p of comGrupo) {
    if (!p.grupoCores.includes(p.codigo)) { assimetria = `${p.codigo} não está no próprio grupo`; break; }
    for (const cod of p.grupoCores) {
      const irmao = porCodigo.get(cod);
      if (!irmao) { assimetria = `${p.codigo} aponta para ${cod}, que não existe no catálogo`; break; }
      if (!irmao.grupoCores.includes(p.codigo)) {
        assimetria = `${p.codigo} aponta para ${cod}, mas ${cod} não aponta de volta`;
        break;
      }
    }
    if (assimetria) break;
  }
  conferir('todo irmão aponta de volta (simetria)', assimetria === null, assimetria || '');

  let misturado = null;
  let corRepetida = null;
  for (const p of comGrupo) {
    const irmaos = p.grupoCores.map((c) => porCodigo.get(c));
    if (irmaos.some((i) => i.subMarca !== p.subMarca)) {
      misturado = `${p.codigo} (${p.subMarca}) está junto de outra sub-marca`;
      break;
    }
    if (irmaos.some((i) => i.grupo !== p.grupo || i.tipoProduto !== p.tipoProduto)) {
      misturado = `${p.codigo} está junto de produto diferente (${p.grupo} / ${p.tipoProduto})`;
      break;
    }
    const cores = irmaos.map((i) => i.cor);
    if (new Set(cores).size !== cores.length) corRepetida = `${p.nome}: ${cores.join(', ')}`;
  }
  conferir('nenhum grupo mistura sub-marcas ou produtos diferentes', misturado === null, misturado || '');
  conferir('dentro do grupo, cada cor aparece uma vez só', corRepetida === null, corRepetida || '');

  const sozinhos = produtos.filter((p) => p.grupoCores.length === 0);
  conferir('item sem irmão fica com lista vazia', sozinhos.every((p) => Array.isArray(p.grupoCores)),
    `(${sozinhos.length} itens de cor única)`);
  conferir('grupo de cor tem sempre pelo menos duas cores',
    comGrupo.every((p) => p.grupoCores.length >= 2));

  console.log('\n== 6. Aba, sub-marca e navegação ==');
  conferir("todo produto vai para a aba 'samsonite'", produtos.every((p) => p.marcaSlug === 'samsonite'));
  conferir('todo produto tem sub-marca preenchida', produtos.every((p) => p.subMarca));
  conferir('a categoria de navegação é a sub-marca', produtos.every((p) => p.categoria === p.subMarca));
  conferir('todo produto tem nome legível', produtos.every((p) => p.nome && p.nome.length > 3));

  // Cor no nome só conta quando é palavra inteira: "ANMICBLACK" é código de
  // modelo do fornecedor, não a cor BLACK repetida.
  const comCorNoNome = produtos.filter((p) => {
    if (!p.cor) return false;
    const re = new RegExp(`\\b${p.cor.replace(/[.*+?^${}()|[\]\\/-]/g, '\\$&')}\\b`, 'i');
    return re.test(p.nome);
  });
  conferir('o nome não repete a cor', comCorNoNome.length === 0,
    comCorNoNome.length ? `(ex.: "${comCorNoNome[0].nome}" cor ${comCorNoNome[0].cor})` : '');
  conferir('todo produto entra ativo', produtos.every((p) => p.ativo === true));

  console.log('\n== 7. Saldo e previsão ==');
  conferir('item sem saldo continua no catálogo',
    produtos.some((p) => p.estoque === 0), `(${relatorio.semSaldo} itens)`);
  conferir('a Samsonite não promete chegada: previsão sempre zero',
    produtos.every((p) => p.previstoTotal === 0 && p.chegadas.length === 0));

  console.log('\n== 8. Imagem de página ==');
  const arquivosGravados = fs.readdirSync(pastaImagens);
  conferir('as imagens de página foram gravadas',
    arquivosGravados.length === relatorio.paginasComImagem && arquivosGravados.length > 0,
    `(${arquivosGravados.length} arquivos)`);
  conferir('uma imagem por página, sem repetir arquivo',
    new Set(produtos.filter((p) => p.imagemPagina).map((p) => p.imagemPagina)).size === arquivosGravados.length);
  conferir('nenhuma foto de produto foi preenchida com a página do catálogo',
    produtos.every((p) => p.imagem === ''));
  conferir('quem tem imagem de página está marcado como ilustrativo',
    produtos.every((p) => (p.imagemPagina ? p.imagemIlustrativa === true : p.imagemIlustrativa === false)));
  conferir('os arquivos começam com o prefixo pedido',
    arquivosGravados.every((f) => f.startsWith('sams-')), `(ex.: ${arquivosGravados[0]})`);
  conferir('as imagens gravadas não estão vazias',
    arquivosGravados.every((f) => fs.statSync(path.join(pastaImagens, f)).size > 1000));

  console.log('\n== 9. Cinco grupos de cor, para conferir a olho ==');
  // Espalho a amostra por sub-marca: pegar os cinco primeiros da lista traria
  // só American Tourister, e o que se quer conferir a olho é se a regra de
  // agrupamento acerta em bases de formato diferente.
  const jaMostrados = new Set();
  const subMarcasMostradas = new Set();
  const amostra = [];
  for (const p of comGrupo) {
    if (subMarcasMostradas.has(p.subMarca)) continue;
    subMarcasMostradas.add(p.subMarca);
    amostra.push(p);
  }
  // Completo com grupos grandes, que são os mais fáceis de conferir.
  amostra.push(...comGrupo.slice().sort((a, b) => b.grupoCores.length - a.grupoCores.length));

  let mostrados = 0;
  for (const p of amostra) {
    if (jaMostrados.has(p.codigo) || p.grupoCores.length < 2) continue;
    p.grupoCores.forEach((c) => jaMostrados.add(c));
    const irmaos = p.grupoCores.map((c) => porCodigo.get(c));
    console.log(`  · ${p.nome}  [${p.subMarca}]  ${irmaos.length} cores`);
    console.log(`      ${irmaos.map((i) => i.cor).join(' | ')}`);
    console.log(`      preço base R$ ${p.precoBase.toFixed(2)}  ·  saldo total ${irmaos.reduce((a, i) => a + i.estoque, 0)}`);
    if (++mostrados === 5) break;
  }

  fs.rmSync(pastaImagens, { recursive: true, force: true });

  console.log(`\n${falhas === 0 ? 'Tudo passou.' : falhas + ' verificação(ões) falharam.'}\n`);
  process.exit(falhas === 0 ? 0 : 1);
})();
